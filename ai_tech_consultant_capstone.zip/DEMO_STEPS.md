# Demo plan (under 10 minutes)
1. Show your face and introduce the business problem for the first 30 seconds.
2. Show health endpoints on ports 8001, 8002 and 8003.
3. Start `POST /ingest/run`, then show `/ingest/status`.
4. Ask a Knowledge Brain question via `POST /query` and show citations/unknown behavior.
5. Add an email with `POST http://localhost:8002/emails`, draft it, then review it. Explain that approval does not send email.
6. Call `POST http://localhost:8003/scope/generate` with a transcript. Show requirements, feasibility checks, estimate, and pending approval.
7. Approve the scope and show status.
8. Show one failure safely, such as unsupported knowledge or unavailable Task 1.
9. Report actual eval results and limitations; do not invent measurements.
