# Sample transcript fixtures (not a substitute for the required real role-plays)

## Meeting 1 — Search
Client: Search is hard to use. Visitors need to find providers by city and service.
Consultant: Check existing filters before custom development?
Client: Yes. We also want a clearer no-results message and sorting by newest listings.
Consultant: Acceptance criteria need confirmation.

## Meeting 2 — Member onboarding
Client: New members should register, verify email, and complete profiles.
Client: Admins need to see incomplete profiles and send reminders.
Consultant: Confirm reminder timing, templates, and permissions. Launch date is unknown.

## Meeting 3 — Follow-up to Meeting 1
Client: Add saved searches and email alerts for matching providers.
Client: Remove sorting by newest listings from the first release.
Client: City and service filters remain top priority.
Consultant: Saved searches and email alerts may be out-of-scope additions requiring a new quote.
