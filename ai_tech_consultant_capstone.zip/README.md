# AI Tech Consultant Capstone

Three connected services based on the assignment:
- Task 1: Python/FastAPI Knowledge Brain with polite sitemap crawl, SQLite storage, retrieval, citations, and human escalation.
- Task 2: strict TypeScript/Express Inbox Agent that calls Task 1, drafts emails, and records human review.
- Task 3: Python/FastAPI Meeting-to-Scope pipeline that calls Task 1, estimates tasks, compares follow-up scope, and requires approval.

## Requirements
Python 3.11+, Node.js 20+, internet access for crawling. Claude generation requires `ANTHROPIC_API_KEY`; without it, local fallback behavior is explicit.

## Run locally
Terminal 1:
```bash
cd task1_knowledge_brain
python -m venv .venv
# Windows: .venv\\Scripts\\activate; macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8001
```
Run ingestion with `POST http://localhost:8001/ingest/run`.

Terminal 2:
```bash
cd task2_inbox_agent
npm install
cp .env.example .env
npm run dev
```
Terminal 3:
```bash
cd task3_meeting_scope
python -m venv .venv
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8003
```

API docs: `http://localhost:8001/docs` and `http://localhost:8003/docs`. Inbox endpoints are listed below.
- Task 1: `GET /health`, `POST /ingest/run`, `GET /ingest/status`, `POST /query`
- Task 2: `POST /emails`, `POST /emails/:id/draft`, `POST /emails/:id/review`, `GET /metrics`
- Task 3: `POST /scope/generate`, `GET /scope/:id`, `POST /scope/:id/approve`

## Safety and limitations
No email is sent externally. Twenty unchanged reviews only create an eligibility signal for low-risk `how_to` emails; they do not activate auto-send. Estimates are planning estimates, not commitments. The starter uses SQLite/lexical search and does not yet implement production image understanding, embeddings, authentication, scheduled daily runs, or mailbox integration. Fill in actual evaluation measurements after running tests; do not invent scores.
