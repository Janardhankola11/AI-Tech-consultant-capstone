# AI_LOG — replace with your actual coding-tool history

The assignment requires the actual Claude Code/Cursor/Antigravity/Codex conversation history. These are prompt templates, not evidence of real usage.

1. “Design three separate services. Tasks 2 and 3 must call Task 1 over HTTP and not duplicate retrieval.”
2. “Implement a typed FastAPI knowledge API with polite sitemap crawling, per-page errors, SQLite persistence, citations, and an honest unknown-answer path.”
3. “Implement strict TypeScript email classification/drafting via the Knowledge Brain API. Human approval is mandatory; 20 unchanged approvals only mark eligibility.”
4. “Implement transcript-to-scope extraction, feasibility checks via Task 1, follow-up diffing, estimate ranges, and approval gates.”
5. “Create 20 evaluation cases per task. Never invent scores, latency, or cost; leave measurements pending until executed.”

Rejected answer to document: do not enable automatic email sending solely because 20 drafts were unchanged. It is unsafe without a measured quality gate, allowed-intent policy, audit log, and kill switch. Replace this with a real example from your own coding session and retain the actual conversation export.
