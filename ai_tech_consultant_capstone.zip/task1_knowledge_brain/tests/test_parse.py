from app.main import parse

def test_parse_removes_navigation():
    title, body = parse('<html><head><title>Help</title></head><body><nav>menu</nav><main>Useful article</main><footer>footer</footer></body></html>')
    assert title == 'Help'
    assert 'Useful article' in body
    assert 'menu' not in body
