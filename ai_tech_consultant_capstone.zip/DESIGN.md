# Design: AI Tech Consultant

## Problem
Support teams repeatedly search help articles, draft replies, and translate meetings into estimates. The Knowledge Brain is the shared source of truth; Task 2 and Task 3 call its API rather than duplicating retrieval.

## Architecture
```text
Public help-center sitemap
          |
          v
[Task 1: Python Knowledge Brain] -- /query API + citations
          |                              |
          v                              v
[Task 2: TypeScript Inbox Agent]   [Task 3: Python Scope Team]
classify -> draft -> human review   requirements -> feasibility -> estimate/proposal
          |                              |
    human approval                 human approval
```

### Task 1
Fetches sitemap URLs politely, extracts article text, hashes content to avoid unnecessary updates, stores records in SQLite, and exposes query/ingestion APIs. Claude answers from retrieved evidence when configured. Without Claude, the system returns source excerpts rather than pretending to synthesize a grounded answer. It should be extended with image captioning, vector search, robust removed-page reconciliation, and a daily scheduler.

### Task 2
Classifies common email intents, calls the Knowledge Brain, drafts in a professional tone, and stores review feedback. Edited/rejected drafts reset the consecutive unchanged counter. Twenty unchanged approvals for `how_to` mark the intent eligible for a future autonomy review, but never send automatically. A production version needs quality thresholds, audit history, a kill switch, and real mailbox integration.

### Task 3
Extracts requirements from transcripts, asks the Knowledge Brain whether settings may already solve a request, produces a task list and estimate range, and compares follow-up requirements against a prior scope. A human must approve before the scope can be marked approved. Heuristic estimates are explicitly low-confidence.

## Model and evaluation
Claude is the primary model through the Anthropic API. `ANTHROPIC_MODEL` is configurable. Compare two model choices on the same 20–30 cases and measure correctness, citation support, safety, latency, and cost before making claims. No evaluation results are prefilled.

## Failure handling
Per-URL crawl failures do not stop the whole crawl. Missing evidence should result in uncertainty/escalation. Task 2 fails safely if the Knowledge Brain is unavailable. Task 3 records unavailable feasibility checks and keeps human approval mandatory.

## Deferred features
Production auth/RBAC, embeddings/vector database, image understanding, full scheduler, durable email storage, mailbox connector, and autonomous sending are deferred to keep the four-day scope manageable.

## Next
Add a real daily scheduler, robust sitemap removal reconciliation, screenshot captions linked to articles, embeddings, persistent audit logs, auth, rate limiting, and actual model comparison results.
